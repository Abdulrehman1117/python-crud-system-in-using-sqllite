from django.shortcuts import render, redirect
from django.shortcuts import render, get_object_or_404, redirect
from .forms import ContactForm
from .models import Contact
from .forms import ContactForm
def contact(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('thank_you')
    else:
        form = ContactForm()
    
    return render(request, 'contact.html', {'form': form})

def thank_you_view(request):
    return render(request, 'thank_you.html')


def contact_list_view(request):
    contacts = Contact.objects.all()  # Fetch all Contact records from the database
    return render(request, 'contact_list.html', {'contacts': contacts})



def contact_update_view(request, id):
    contact = get_object_or_404(Contact, id=id)
    
    if request.method == 'POST':
        form = ContactForm(request.POST, instance=contact)
        if form.is_valid():
            form.save()
            return redirect('contact_list')  # Redirect after update
    else:
        form = ContactForm(instance=contact)
    
    return render(request, 'contact_update.html', {'form': form, 'contact': contact})




def contact_delete_view(request, id):
    contact = get_object_or_404(Contact, id=id)
    if request.method == 'POST':
        contact.delete()
        return redirect('contact_list')  # Redirect to the contact list page after deletion
    return render(request, 'contact_confirm_delete.html', {'contact': contact})